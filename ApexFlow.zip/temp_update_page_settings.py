
    def update_page_settings(self, settings):
        """تحديث إعدادات الصفحة الحالية في واجهة الإسقاط"""
        self.current_page_settings = settings
        # يمكن إضافة المزيد من المنطق هنا حسب الحاجة
