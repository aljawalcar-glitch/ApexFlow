# -*- coding: utf-8 -*-
"""
مساعدات لواجهة المستخدم - دوال لإنشاء عناصر واجهة مستخدم مشتركة
"""

from PySide6.QtWidgets import QPushButton, QLabel, QDialog, QVBoxLayout, QHBoxLayout, QSpacerItem, QSizePolicy, QComboBox, QWidget
from PySide6.QtGui import QPainter, QColor, QLinearGradient
from PySide6.QtCore import Signal
from .theme_manager import apply_theme_style, global_theme_manager
from modules.translator import tr
from .global_styles import get_font_settings

def get_special_button_style(color_rgb="13, 110, 253"):
    """Generate a special button style with a given color."""
    font_settings = get_font_settings()
    return f"""
        QPushButton {{
            background: rgba({color_rgb}, 0.2);
            border: 1px solid rgba({color_rgb}, 0.4);
            border-radius: 8px;
            font-size: {font_settings['size']}px;
            font-weight: bold;
            padding: 12px 24px;
        }}
        QPushButton:hover {{
            background: rgba({color_rgb}, 0.3);
            border: 1px solid rgba({color_rgb}, 0.5);
        }}
        QPushButton:pressed {{
            background: rgba({color_rgb}, 0.1);
        }}
    """

def get_scroll_area_style():
    """تنسيق منطقة التمرير - ربط مباشر بالمدير المركزي"""
    colors = global_theme_manager.get_current_colors()
    accent = global_theme_manager.current_accent
    return f"""
        QScrollArea {{
            background: transparent;
            border: none;
        }}
        QScrollArea > QWidget > QWidget {{
            background: transparent;
        }}
        QScrollBar:vertical {{
            background: transparent;
            width: 12px;
            border-radius: 6px;
            margin: 0px;
        }}
        QScrollBar::handle:vertical {{
            background: {accent};
            border-radius: 6px;
            min-height: 20px;
            margin: 2px;
        }}
        QScrollBar::handle:vertical:hover {{
            background: {colors['text_accent']};
        }}
        QScrollBar::handle:vertical:pressed {{
            background: {colors['text']};
        }}
        QScrollBar::add-line:vertical,
        QScrollBar::sub-line:vertical {{
            height: 0px;
            background: none;
        }}
        QScrollBar::add-page:vertical,
        QScrollBar::sub-page:vertical {{
            background: none;
        }}
    """

def create_button(text, on_click=None, is_default=False):
    """
    إنشاء زر بتصميم موحد.
    """
    button = QPushButton(text)
    if on_click:
        button.clicked.connect(on_click)
    
    # تطبيق نمط الثيمة على الزر
    apply_theme_style(button, "button", auto_register=True)
    
    if is_default:
        button.setDefault(True)
        # يمكنك إضافة نمط خاص للزر الافتراضي هنا إذا أردت
        
    return button

def create_title(text):
    """
    إنشاء عنوان بتصميم موحد.
    """
    title = QLabel(text)
    # تطبيق نمط الثيمة على العنوان
    apply_theme_style(title, "title_text", auto_register=True)
    title.setProperty("class", "title_label")
    return title

def create_section_label(text):
    """
    إنشاء تسمية قسم بتصميم موحد.
    """
    label = QLabel(text)
    # تطبيق نمط الثيمة على تسمية القسم
    apply_theme_style(label, "label", auto_register=True)
    label.setStyleSheet(label.styleSheet() + "font-weight: bold;")
    label.setProperty("class", "section_label")
    return label

def create_info_label(text):
    """
    إنشاء تسمية معلومات بتصميم موحد.
    """
    label = QLabel(text)
    # تطبيق نمط الثيمة على تسمية المعلومات
    apply_theme_style(label, "secondary_text", auto_register=True)
    return label

class CustomMessageBox(QDialog):
    """
    مربع حوار مخصص متوافق مع السمات.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("warning"))
        self.setModal(True)
        apply_theme_style(self, "dialog")

        self.layout = QVBoxLayout(self)
        self.layout.setSpacing(15)
        self.layout.setContentsMargins(20, 20, 20, 20)

        self.message_label = QLabel()
        self.message_label.setWordWrap(False) # تعديل: منع التفاف النص
        apply_theme_style(self.message_label, "label")
        self.layout.addWidget(self.message_label)

        self.layout.addSpacerItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.buttons_layout = QHBoxLayout()
        self.layout.addLayout(self.buttons_layout)

        self.result = QDialog.Rejected

    def setText(self, text):
        self.message_label.setText(text)

    def addButton(self, text, role):
        button = create_button(text)
        from PySide6.QtWidgets import QDialogButtonBox
        
        # تبسيط: استخدام القيم القياسية. تجاهل = مقبول، إلغاء = مرفوض
        dialog_result = QDialog.Rejected # القيمة الافتراضية
        if role == QDialogButtonBox.DestructiveRole:
            dialog_result = QDialog.Accepted # زر التجاهل سيعيد "مقبول"
        elif role == QDialogButtonBox.RejectRole:
            dialog_result = QDialog.Rejected # زر الإلغاء سيعيد "مرفوض"

        button.clicked.connect(lambda r=dialog_result: self.done(r))
        self.buttons_layout.addWidget(button)
        return button

    def exec(self):
        return super().exec()

class FocusAwareComboBox(QComboBox):
    """
    QComboBox مخصص يرسل إشارة عند الحصول على التركيز أو فقدانه.
    """
    focus_in = Signal()
    focus_out = Signal()

    def focusInEvent(self, event):
        super().focusInEvent(event)
        self.focus_in.emit()

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        self.focus_out.emit()
