"""
وحدة الأدوات المساعدة للتطبيق
تحتوي على الدوال المساعدة للنظام والملفات والموارد
"""

import os
import psutil
from PySide6.QtWidgets import QMessageBox, QProgressDialog
from PySide6.QtCore import Qt
from src.utils.translator import tr
from config.version import APP_NAME

def get_icon_path():
    """العثور على مسار الأيقونة الصحيح سواء كان التطبيق مجمداً أم لا"""
    import sys

    if getattr(sys, 'frozen', False):
        # المسار داخل الملف التنفيذي
        base_path = sys._MEIPASS
    else:
        # المسار في بيئة التطوير
        base_path = os.path.abspath(".")

    # مسارات محتملة للأيقونة
    possible_paths = [
        os.path.join(base_path, "assets", "icons", f"{APP_NAME}.ico"),
        os.path.join(base_path, f"{APP_NAME}.ico"),
        os.path.join(base_path, "assets", "logo.png")
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    return None

def check_system_resources(file_path):
    """التحقق من موارد النظام قبل معالجة الملفات الكبيرة"""
    try:
        # حجم الملف بالميجابايت
        file_size = os.path.getsize(file_path) / (1024 * 1024)
        
        # الذاكرة المتاحة بالميجابايت
        available_memory = psutil.virtual_memory().available / (1024 * 1024)
        
        # تحذير إذا كان الملف كبير والذاكرة قليلة
        if file_size > 100 and available_memory < file_size * 3:
            return {
                'proceed': False,
                'file_size': file_size,
                'available_memory': available_memory,
                'warning': f"الملف كبير ({file_size:.1f} MB) والذاكرة المتاحة قليلة ({available_memory:.1f} MB).\nقد تستغرق العملية وقتاً أطول. هل تريد المتابعة؟"
            }
        
        return {'proceed': True}
    except:
        # في حالة عدم توفر psutil، نتابع بدون تحقق
        return {'proceed': True}

def show_progress_dialog(parent, title, message, maximum=0):
    """إنشاء وإظهار حوار التقدم للعمليات الطويلة"""
    progress = QProgressDialog(message, tr("cancel_button"), 0, maximum, parent)
    progress.setWindowTitle(title)
    progress.setWindowModality(Qt.WindowModal)
    progress.setMinimumDuration(1000)  # إظهار بعد ثانية واحدة
    progress.setValue(0)
    return progress

def validate_pdf_files(files):
    """التحقق من صحة ملفات PDF"""
    if not files:
        return False, "لم يتم اختيار أي ملفات"
    
    invalid_files = []
    for file in files:
        if not os.path.exists(file):
            invalid_files.append(f"{file} (غير موجود)")
        elif not file.lower().endswith('.pdf'):
            invalid_files.append(f"{file} (ليس ملف PDF)")
    
    if invalid_files:
        return False, f"ملفات غير صالحة:\n" + "\n".join(invalid_files)
    
    return True, "جميع الملفات صالحة"

def get_output_path(parent, settings_data, default_name="output.pdf"):
    """الحصول على مسار الحفظ بناءً على الإعدادات"""
    from PySide6.QtWidgets import QFileDialog
    
    if settings_data.get('save_mode') == 'fixed' and settings_data.get('save_path'):
        return os.path.join(settings_data['save_path'], default_name)
    else:
        return QFileDialog.getSaveFileName(parent, "حفظ باسم", default_name, "PDF Files (*.pdf)")[0]

def show_success_message(parent, message):
    """عرض رسالة نجاح باستخدام نظام الإشعارات"""
    try:
        # الحصول على مدير الإشعارات من النافذة الرئيسية
        if hasattr(parent, 'notification_manager'):
            parent.notification_manager.show_notification(message, "success", duration=4000)
        else:
            # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
            QMessageBox.information(parent, "نجاح", message)
    except Exception as e:
        # Fallback to QMessageBox if notification system fails
        QMessageBox.information(parent, "نجاح", message)

def show_error_message(parent, message):
    """عرض رسالة خطأ باستخدام نظام الإشعارات"""
    try:
        # الحصول على مدير الإشعارات من النافذة الرئيسية
        if hasattr(parent, 'notification_manager'):
            parent.notification_manager.show_notification(message, "error", duration=4000)
        else:
            # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
            QMessageBox.critical(parent, "خطأ", message)
    except Exception as e:
        # Fallback to QMessageBox if notification system fails
        QMessageBox.critical(parent, "خطأ", message)


class FileManager:
    """مدير الملفات الموحد - مسؤول عن جميع عمليات الملفات"""

    def __init__(self, main_window):
        self.main_window = main_window

    def select_file(self, title="اختيار ملف", file_filter="All Files (*)", multiple=False):
        """اختيار ملف واحد أو عدة ملفات مع مرشح مخصص."""
        from PySide6.QtWidgets import QFileDialog
        import os

        full_title = f"{APP_NAME} - {title}"
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")

        # إنشاء نافذة حوار اختيار الملفات
        dialog = QFileDialog(self.main_window, full_title, default_dir, file_filter)

        # جعل النافذة تظهر فوق الكل وتعطل الوصول للنافذة الرئيسية
        dialog.setWindowModality(Qt.ApplicationModal)
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowStaysOnTopHint)

        if multiple:
            dialog.setFileMode(QFileDialog.ExistingFiles)
        else:
            dialog.setFileMode(QFileDialog.ExistingFile)

        if dialog.exec_() == QFileDialog.Accepted:
            if multiple:
                return dialog.selectedFiles()
            else:
                return dialog.selectedFiles()[0] if dialog.selectedFiles() else None
        return None

    def select_pdf_files(self, title="اختيار ملفات PDF", multiple=True):
        """اختيار ملفات PDF"""
        return self.select_file(title, "PDF Files (*.pdf)", multiple)

    def select_image_files(self, title="اختيار ملفات الصور"):
        """اختيار ملفات الصور"""
        from PySide6.QtWidgets import QFileDialog
        import os

        full_title = f"{APP_NAME} - {title}"
        image_filter = "Image Files (*.png *.jpg *.jpeg *.bmp *.tiff)"
        # مجلد Documents كافتراضي
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")

        files, _ = QFileDialog.getOpenFileNames(
            self.main_window,
            full_title,
            default_dir,
            image_filter
        )
        return files

    def select_text_file(self, title="اختيار ملف نصي"):
        """اختيار ملف نصي"""
        from PySide6.QtWidgets import QFileDialog
        import os

        full_title = f"{APP_NAME} - {title}"
        text_filter = "Text Files (*.txt)"
        # مجلد Documents كافتراضي
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")

        file, _ = QFileDialog.getOpenFileName(
            self.main_window,
            full_title,
            default_dir,
            text_filter
        )
        return file

    def select_save_location(self, title="حفظ الملف", default_name="output.pdf", file_filter="PDF Files (*.pdf)"):
        """اختيار مكان الحفظ"""
        from PySide6.QtWidgets import QFileDialog
        import os

        full_title = f"{APP_NAME} - {title}"
        # مجلد Documents كافتراضي مع اسم الملف
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")
        default_path = os.path.join(default_dir, default_name)

        file_path, _ = QFileDialog.getSaveFileName(
            self.main_window,
            full_title,
            default_path,
            file_filter
        )
        return file_path

    def select_directory(self, title="اختيار مجلد"):
        """اختيار مجلد باستخدام نافذة النظام"""
        from PySide6.QtWidgets import QFileDialog
        import os

        # الحصول على مجلد Documents كافتراضي
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")

        directory = QFileDialog.getExistingDirectory(
            self.main_window,
            f"{APP_NAME} - {title}",
            default_dir
        )
        return directory if directory else None

    def get_pdf_files_from_folder(self, folder_path):
        """الحصول على جميع ملفات PDF من مجلد معين"""
        pdf_files = []
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith('.pdf'):
                    pdf_files.append(os.path.join(root, file))
        return pdf_files

    def get_output_path_with_settings(self, settings_data, default_name="output.pdf"):
        """الحصول على مسار الحفظ بناءً على الإعدادات"""
        if settings_data.get('save_mode') == 'fixed' and settings_data.get('save_path'):
            return os.path.join(settings_data['save_path'], default_name)
        else:
            return self.select_save_location("حفظ الملف", default_name)


class MessageManager:
    """مدير الرسائل الموحد - مسؤول عن جميع الرسائل"""

    def __init__(self, main_window):
        self.main_window = main_window

    def show_success(self, message, title="نجح"):
        """عرض رسالة نجاح باستخدام نظام الإشعارات"""
        try:
            # الحصول على مدير الإشعارات من النافذة الرئيسية
            if hasattr(self.main_window, 'notification_manager'):
                self.main_window.notification_manager.show_notification(message, "success", duration=4000)
                return 0  # القيمة المرجعة عند النجاح
            else:
                # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
                from PySide6.QtWidgets import QMessageBox
                from PySide6.QtGui import QIcon

                msg_box = QMessageBox(self.main_window)
                msg_box.setWindowTitle(f"{APP_NAME} - {title}")
                msg_box.setText(message)
                msg_box.setIcon(QMessageBox.Information)

                # تطبيق السمة
                try:
                    from src.managers.theme_manager import make_theme_aware
                    make_theme_aware(msg_box, "dialog")
                except:
                    pass

                return msg_box.exec()
        except Exception as e:
            # Fallback to QMessageBox if notification system fails
            from PySide6.QtWidgets import QMessageBox
            from PySide6.QtGui import QIcon

            msg_box = QMessageBox(self.main_window)
            msg_box.setWindowTitle(f"{APP_NAME} - {title}")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Information)
            return msg_box.exec()

    def show_error(self, message, title="خطأ", details=""):
        """عرض رسالة خطأ باستخدام نظام الإشعارات"""
        try:
            # الحصول على مدير الإشعارات من النافذة الرئيسية
            if hasattr(self.main_window, 'notification_manager'):
                # إضافة التفاصيل إلى الرسالة إذا وجدت
                full_message = f"{message}"
                if details:
                    full_message += f" ({details})"
                self.main_window.notification_manager.show_notification(full_message, "error", duration=4000)
                return 0  # القيمة المرجعة عند النجاح
            else:
                # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
                from PySide6.QtWidgets import QMessageBox
                from PySide6.QtGui import QIcon

                msg_box = QMessageBox(self.main_window)
                msg_box.setWindowTitle(f"{APP_NAME} - {title}")
                msg_box.setText(message)
                msg_box.setIcon(QMessageBox.Critical)

                if details:
                    msg_box.setDetailedText(details)

                # تطبيق السمة
                try:
                    from src.managers.theme_manager import make_theme_aware
                    make_theme_aware(msg_box, "dialog")
                except:
                    pass

                return msg_box.exec()
        except Exception as e:
            # Fallback to QMessageBox if notification system fails
            from PySide6.QtWidgets import QMessageBox
            from PySide6.QtGui import QIcon

            msg_box = QMessageBox(self.main_window)
            msg_box.setWindowTitle(f"{APP_NAME} - {title}")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Critical)
            if details:
                msg_box.setDetailedText(details)
            return msg_box.exec()

    def show_warning(self, message, title="تحذير"):
        """عرض رسالة تحذير باستخدام نظام الإشعارات"""
        try:
            # الحصول على مدير الإشعارات من النافذة الرئيسية
            if hasattr(self.main_window, 'notification_manager'):
                self.main_window.notification_manager.show_notification(message, "warning", duration=4000)
                return 0  # القيمة المرجعة عند النجاح
            else:
                # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
                from PySide6.QtWidgets import QMessageBox
                from PySide6.QtGui import QIcon

                msg_box = QMessageBox(self.main_window)
                msg_box.setWindowTitle(f"{APP_NAME} - {title}")
                msg_box.setText(message)
                msg_box.setIcon(QMessageBox.Warning)

                # تطبيق السمة
                try:
                    from src.managers.theme_manager import make_theme_aware
                    make_theme_aware(msg_box, "dialog")
                except:
                    pass

                return msg_box.exec()
        except Exception as e:
            # Fallback to QMessageBox if notification system fails
            from PySide6.QtWidgets import QMessageBox
            from PySide6.QtGui import QIcon

            msg_box = QMessageBox(self.main_window)
            msg_box.setWindowTitle(f"{APP_NAME} - {title}")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Warning)
            return msg_box.exec()

    def ask_for_save_confirmation(self, inner_widget):
        """Asks the user to confirm saving changes and handles the response."""
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QHBoxLayout, QPushButton, QCheckBox
        from src.managers.theme_manager import make_theme_aware
        from src.utils import settings

        dialog = QDialog(self.main_window)
        dialog.setWindowTitle(tr("confirm_title"))
        dialog.setMinimumWidth(400)
        make_theme_aware(dialog, "dialog")

        layout = QVBoxLayout(dialog)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        message_label = QLabel(tr("unsaved_changes_prompt"))
        message_label.setWordWrap(True)
        make_theme_aware(message_label, "label")
        layout.addWidget(message_label)

        from src.ui.widgets.toggle_switch import ToggleSwitch
        
        dont_ask_layout = QHBoxLayout()
        dont_ask_label = QLabel(tr("dont_ask_again_and_discard"))
        make_theme_aware(dont_ask_label, "label")
        dont_ask_checkbox = ToggleSwitch()
        dont_ask_layout.addWidget(dont_ask_label)
        dont_ask_layout.addStretch()
        dont_ask_layout.addWidget(dont_ask_checkbox)
        layout.addLayout(dont_ask_layout)

        buttons_layout = QHBoxLayout()
        save_button = QPushButton(tr("save_and_close"))
        make_theme_aware(save_button, "button")
        buttons_layout.addWidget(save_button)

        discard_button = QPushButton(tr("discard_changes"))
        make_theme_aware(discard_button, "button")
        buttons_layout.addWidget(discard_button)

        cancel_button = QPushButton(tr("cancel_button"))
        make_theme_aware(cancel_button, "button")
        buttons_layout.addWidget(cancel_button)

        layout.addLayout(buttons_layout)

        # Connect signals to dialog slots
        save_button.clicked.connect(lambda: self._handle_save_confirmation(inner_widget, dialog, dont_ask_checkbox, "save"))
        discard_button.clicked.connect(lambda: self._handle_save_confirmation(inner_widget, dialog, dont_ask_checkbox, "discard"))
        cancel_button.clicked.connect(dialog.reject)

        return dialog.exec_()

    def _handle_save_confirmation(self, widget, dialog, checkbox, action):
        """Handles the logic for the save confirmation dialog buttons."""
        from src.utils import settings
        if checkbox.isChecked():
            settings.set_setting("dont_ask_again_and_discard", True)
            self.show_info(tr("dont_ask_again_info"))

        if action == "save":
            if hasattr(widget, 'save_all_settings'):
                widget.save_all_settings()
            dialog.accept()
        elif action == "discard":
            dialog.accept()

    def ask_question(self, message, title="سؤال"):
        """طرح سؤال مع نعم/لا باستخدام نظام الإشعارات"""
        try:
            # الحصول على مدير الإشعارات من النافذة الرئيسية
            if hasattr(self.main_window, 'notification_manager'):
                # استخدام نظام الإشعارات لعرض السؤال
                # ملاحظة: نظام الإشعارات الحالي لا يدعم الأسئلة (نعم/لا) بشكل مباشر
                # لذلك سنستخدم QMessageBox كخيار أساسي هنا
                from PySide6.QtWidgets import QMessageBox
                from PySide6.QtGui import QIcon

                msg_box = QMessageBox(self.main_window)
                msg_box.setWindowTitle(f"{APP_NAME} - {title}")
                msg_box.setText(message)
                msg_box.setIcon(QMessageBox.Question)
                msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)

                # تطبيق السمة
                try:
                    from src.managers.theme_manager import make_theme_aware
                    make_theme_aware(msg_box, "dialog")
                except:
                    pass

                return msg_box.exec() == QMessageBox.Yes
            else:
                # إذا لم يتم العثور على مدير الإشعارات، استخدام QMessageBox كخيار احتياطي
                from PySide6.QtWidgets import QMessageBox
                from PySide6.QtGui import QIcon

                msg_box = QMessageBox(self.main_window)
                msg_box.setWindowTitle(f"{APP_NAME} - {title}")
                msg_box.setText(message)
                msg_box.setIcon(QMessageBox.Question)
                msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)

                # تطبيق السمة
                try:
                    from src.managers.theme_manager import make_theme_aware
                    make_theme_aware(msg_box, "dialog")
                except:
                    pass

                return msg_box.exec() == QMessageBox.Yes
        except Exception as e:
            # Fallback to QMessageBox if notification system fails
            from PySide6.QtWidgets import QMessageBox
            from PySide6.QtGui import QIcon

            msg_box = QMessageBox(self.main_window)
            msg_box.setWindowTitle(f"{APP_NAME} - {title}")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Question)
            msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            return msg_box.exec() == QMessageBox.Yes

    def show_warning(self, message, title="تحذير"):
        """عرض رسالة تحذير"""
        from PySide6.QtWidgets import QMessageBox
        from PySide6.QtGui import QIcon

        msg_box = QMessageBox(self.main_window)
        msg_box.setWindowTitle(f"{APP_NAME} - {title}")
        msg_box.setText(message)
        msg_box.setIcon(QMessageBox.Warning)

        # تطبيق السمة
        try:
            from src.managers.theme_manager import make_theme_aware
            make_theme_aware(msg_box, "dialog")
        except:
            pass

        return msg_box.exec()


class OperationsManager:
    """
    مدير العمليات الموحد - مسؤول عن جميع عمليات PDF.
    يستخدم التحميل الكسول للوحدات لضمان بدء تشغيل سريع.
    """

    def __init__(self, main_window, file_manager, message_manager):
        self.main_window = main_window
        self.file_manager = file_manager
        self.message_manager = message_manager
        self._merge = None
        self._split = None
        self._compress = None
        self._rotate = None
        self._convert = None
        self._security = None
    
    # إضافة دوال مساعدة للصفحات
    def add_files_to_page(self, page, files):
        """إضافة ملفات إلى صفحة"""
        from utils.page_helpers import PageHelpers
        return PageHelpers.add_files_to_page(page, files)
    
    def execute_page_action(self, page, action):
        """تنفيذ إجراء على صفحة"""
        from utils.page_helpers import PageHelpers
        return PageHelpers.execute_page_action(page, action)
    
    def get_current_page_widget(self):
        """الحصول على ويدجت الصفحة الحالية"""
        from utils.page_helpers import PageHelpers
        return PageHelpers.get_current_page_widget(self.main_window)
    
    def get_page_index_for_action(self, action):
        """الحصول على فهرس الصفحة من الإجراء"""
        from utils.page_helpers import PageHelpers
        return PageHelpers.get_page_index(action)

    @property
    def security_module(self):
        if self._security is None:
            from src.core import security
            self._security = security
        return self._security

    @property
    def merge_module(self):
        if self._merge is None:
            from src.core import merge
            self._merge = merge
        return self._merge

    @property
    def split_module(self):
        if self._split is None:
            from src.core import split
            self._split = split
        return self._split

    @property
    def compress_module(self):
        if self._compress is None:
            from src.core import compress
            self._compress = compress
        return self._compress

    @property
    def rotate_module(self):
        if self._rotate is None:
            from src.core import rotate
            self._rotate = rotate
        return self._rotate

    @property
    def convert_module(self):
        if self._convert is None:
            from src.core import convert
            self._convert = convert
        return self._convert

    def merge_files(self, page):
        """تنفيذ عملية دمج الملفات"""
        try:
            files = page.file_list_frame.get_valid_files()
            if len(files) < 2:
                page.notification_manager.show_notification("يجب اختيار ملفين على الأقل للدمج", "warning")
                return False

            # الحصول على مسار الحفظ
            from src.utils import settings
            settings_data = settings.load_settings()
            output = self.file_manager.get_output_path_with_settings(settings_data, "merged.pdf")

            if output:
                # تنفيذ عملية الدمج
                # استخدام إعدادات الدمج
                merge_settings = settings_data.get("merge_settings", {})
                if merge_settings.get("add_bookmarks", True):
                    success = self.merge_module.merge_pdfs_with_bookmarks(files, output)
                else:
                    success = self.merge_module.merge_pdfs(files, output)

                if success:
                    self.message_manager.show_success("تم دمج الملفات بنجاح!")
                    page.file_list_frame.clear_all_files()
                    return True
                else:
                    self.message_manager.show_error("فشل في دمج الملفات. تحقق من صحة الملفات.")
                    return False

        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def split_file(self, page):
        """تنفيذ عملية تقسيم الملف مع استخدام المسار التلقائي"""
        try:
            files = page.file_list_frame.get_valid_files()
            if len(files) != 1:
                self.message_manager.show_error("يجب اختيار ملف واحد فقط للتقسيم")
                return False

            file = files[0]

            # استخدام المسار التلقائي من الصفحة إذا كان متوفراً
            output_dir = None
            if hasattr(page, 'get_save_path'):
                output_dir = page.get_save_path()

            # إذا لم يكن هناك مسار تلقائي، اطلب من المستخدم اختيار مجلد
            if not output_dir:
                output_dir = self.file_manager.select_directory("اختيار مجلد الحفظ")

            if output_dir:
                # التأكد من وجود المجلد
                if not os.path.exists(output_dir):
                    try:
                        os.makedirs(output_dir, exist_ok=True)
                    except Exception as e:
                        self.message_manager.show_error(f"فشل في إنشاء مجلد الحفظ: {str(e)}")
                        return False

                success = self.split_module.split_pdf_advanced(file, output_dir)

                if success:
                    page.notification_manager.show_notification(f"{tr('split_completed_successfully')}\n{tr('pages_saved_in')}: {output_dir}", "success", duration=4000)
                    page.file_list_frame.clear_all_files()
                    # إخفاء التخطيط الكامل بعد النجاح
                    if hasattr(page, 'save_and_split_widget'):
                        page.save_and_split_widget.setVisible(False)
                    return True
                else:
                    page.notification_manager.show_notification(tr("split_failed"), "error", duration=4000)
                    return False

        except Exception as e:
            page.notification_manager.show_notification(f"{tr('split_error')}: {str(e)}", "error")
            return False

    def compress_files(self, page):
        """تنفيذ عملية ضغط الملفات"""
        try:
            files = page.selected_files
            if not files:
                page.notification_manager.show_notification(tr("select_one_file_message"), "warning")
                return False

            save_path = page.get_save_path()
            if not save_path:
                page.notification_manager.show_notification(tr("save_path_not_set"), "error")
                return False

            if not os.path.exists(save_path):
                os.makedirs(save_path, exist_ok=True)

            compression_level = page.get_batch_compression_level()

            for file in files:
                output_filename = f"compressed_{os.path.basename(file)}"
                output_path = os.path.join(save_path, output_filename)

                success = self.compress_module.compress_pdf(file, output_path, compression_level)
                if success:
                    page.notification_manager.show_notification(f"{tr('file_compressed_successfully')}: {os.path.basename(file)}", "success", duration=4000)
                else:
                    page.notification_manager.show_notification(f"{tr('compress_failed')}: {os.path.basename(file)}", "error", duration=4000)
                    return False
            return True

        except Exception as e:
            page.notification_manager.show_notification(f"{tr('compress_error')}: {str(e)}", "error")
            return False

    def rotate_files(self, page, angle=90):
        """تنفيذ عملية تدوير الملفات"""
        try:
            files = page.file_list_frame.get_valid_files()
            if not files:
                self.message_manager.show_error("يجب اختيار ملف واحد على الأقل للتدوير")
                return False

            from src.utils import settings
            settings_data = settings.load_settings()

            for file in files:
                output = self.file_manager.get_output_path_with_settings(
                    settings_data,
                    f"rotated_{os.path.basename(file)}"
                )

                if output:
                    success = self.rotate_module.rotate_pdf(file, output, angle)
                    if success:
                        self.message_manager.show_success(f"تم تدوير الملف {os.path.basename(file)} بزاوية {angle} درجة بنجاح!")
                    else:
                        self.message_manager.show_error(f"فشل في تدوير الملف {os.path.basename(file)}.")
                        return False

            page.file_list_frame.clear_all_files()
            return True

        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def pdf_to_images(self, files, output_dir):
        """تحويل PDF إلى صور"""
        try:
            # يفترض أن files تحتوي على ملف واحد فقط لهذه العملية
            if not files or len(files) != 1:
                self.message_manager.show_error("يجب تحديد ملف PDF واحد فقط.")
                return False
            
            success = self.convert_module.pdf_to_images(files[0], output_dir)
            if success:
                return True
            else:
                self.message_manager.show_error("فشل في تحويل PDF إلى صور.")
                return False
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def images_to_pdf(self, files, output_path):
        """تحويل صور إلى PDF"""
        try:
            if not files:
                self.message_manager.show_error("يجب تحديد صورة واحدة على الأقل.")
                return False

            success = self.convert_module.images_to_pdf(files, output_path)
            if success:
                return True
            else:
                self.message_manager.show_error("فشل في تحويل الصور إلى PDF.")
                return False
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def pdf_to_text(self, files, output_path):
        """استخراج النص من PDF"""
        try:
            if not files or len(files) != 1:
                self.message_manager.show_error("يجب تحديد ملف PDF واحد فقط.")
                return False

            success = self.convert_module.pdf_to_text(files[0], output_path)
            if success:
                return True
            else:
                self.message_manager.show_error("فشل في استخراج النص من PDF.")
                return False
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def text_to_pdf(self, files, output_path):
        """تحويل نص إلى PDF"""
        try:
            if not files or len(files) != 1:
                self.message_manager.show_error("يجب تحديد ملف نصي واحد فقط.")
                return False

            success = self.convert_module.text_to_pdf(files[0], output_path, 12)
            if success:
                return True
            else:
                self.message_manager.show_error("فشل في تحويل النص إلى PDF.")
                return False
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ غير متوقع: {str(e)}")
            return False

    def _check_pywin32_available(self):
        """فحص توفر pywin32 بهدوء"""
        try:
            import win32print
            return True
        except ImportError:
            return False

    def get_available_printers(self):
        """الحصول على قائمة بأسماء الطابعات المتاحة"""
        try:
            import win32print
            printers = win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)
            printer_names = [printer[2] for printer in printers]

            return printer_names if printer_names else ["Microsoft Print to PDF"]

        except ImportError:
            # تسجيل الخطأ بهدوء بدون إظهار رسائل للمستخدم
            from src.utils.logger import debug
            return ["Microsoft Print to PDF"]  # طابعة افتراضية

        except Exception as e:
            from src.utils.logger import warning
            warning(f"فشل في جلب قائمة الطابعات: {str(e)}")

            # عرض تحذير بسيط
            try:
                self.message_manager.show_warning(f"تحذير: لا يمكن الوصول لجميع الطابعات")
            except:
                print(f"تحذير: مشكلة في الطابعات - {str(e)}")

            return ["Microsoft Print to PDF"]  # طابعة افتراضية

    def print_files(self, files, printer_name=None, parent_widget=None):
        """طباعة ملفات PDF المحددة باستخدام win32print API مباشرة."""
        if not files:
            self.message_manager.show_error("لم يتم تحديد ملفات للطباعة.")
            return False

        try:
            import win32print
            from PySide6.QtWidgets import QProgressDialog, QApplication
            from src.utils.logger import info, error

            progress = QProgressDialog(parent_widget)
            progress.setWindowTitle(tr("printing_title"))
            progress.setLabelText(tr("printing_prep"))
            progress.setRange(0, len(files))
            progress.setModal(True)
            progress.setCancelButtonText(tr("cancel_button"))
            progress.show()

            if not printer_name:
                printer_name = win32print.GetDefaultPrinter()
            info(f"Starting print job for {len(files)} files on printer: {printer_name}")

            for i, file_path in enumerate(files):
                if progress.wasCanceled():
                    info("Print job canceled by user.")
                    break
                
                progress.setValue(i)
                progress.setLabelText(f"طباعة ملف: {os.path.basename(file_path)} ({i+1} من {len(files)})")
                QApplication.processEvents()

                try:
                    info(f"Opening printer: {printer_name}")
                    h_printer = win32print.OpenPrinter(printer_name)
                    try:
                        info(f"Starting print document for: {file_path}")
                        doc_info = ("ApexFlow Print Job", None, "RAW")
                        job_id = win32print.StartDocPrinter(h_printer, 1, doc_info)
                        try:
                            win32print.StartPagePrinter(h_printer)
                            with open(file_path, "rb") as f:
                                data = f.read()
                            win32print.WritePrinter(h_printer, data)
                            win32print.EndPagePrinter(h_printer)
                        finally:
                            win32print.EndDocPrinter(h_printer)
                            info(f"Print job #{job_id} finished for: {file_path}")
                    finally:
                        win32print.ClosePrinter(h_printer)
                        info(f"Printer closed: {printer_name}")
                except Exception as e:
                    error_msg = f"فشل في طباعة الملف {os.path.basename(file_path)}: {e}"
                    error(error_msg)
                    self.message_manager.show_error(f"فشل طباعة الملف:\n{os.path.basename(file_path)}\n{e}")
                    progress.close()
                    return False
            
            progress.setValue(len(files))
            if not progress.wasCanceled():
                self.message_manager.show_success("تم إرسال جميع الملفات إلى طابور الطباعة بنجاح.")
            
            return True

        except ImportError:
            error_msg = "مكتبة pywin32 غير مثبتة. يرجى تثبيتها باستخدام: pip install pywin32"
            self.message_manager.show_error(error_msg)
            error("pywin32 is not installed.")
            return False
        except Exception as e:
            error(f"خطأ غير متوقع أثناء الطباعة: {str(e)}")
            self.message_manager.show_error(f"حدث خطأ غير متوقع أثناء الطباعة:\n{str(e)}")
            return False

    def get_output_path(self, file_path, suffix):
        """إنشاء مسار إخراج افتراضي مع لاحقة مخصصة"""
        dir_name, file_name = os.path.split(file_path)
        base_name, ext = os.path.splitext(file_name)
        return os.path.join(dir_name, f"{base_name}{suffix}{ext}")

    def get_pdf_properties(self, file_path):
        """الحصول على خصائص ملف PDF"""
        try:
            return self.security_module.get_pdf_metadata(file_path)
        except Exception as e:
            self.message_manager.show_error(f"فشل في قراءة خصائص الملف: {e}")
            return None

    def encrypt_pdf(self, file_path, output_path, password, owner_password, permissions):
        """تشفير ملف PDF"""
        try:
            success = self.security_module.encrypt_pdf(file_path, output_path, password, owner_password, permissions)
            if success:
                self.message_manager.show_success(f"تم تشفير الملف بنجاح!\nحُفظ في: {output_path}")
            else:
                self.message_manager.show_error("فشل تشفير الملف.")
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ أثناء التشفير: {e}")

    def decrypt_pdf(self, file_path, output_path, password):
        """فك تشفير ملف PDF"""
        try:
            success = self.security_module.decrypt_pdf(file_path, output_path, password)
            if success:
                self.message_manager.show_success(f"تم فك تشفير الملف بنجاح!\nحُفظ في: {output_path}")
            else:
                self.message_manager.show_error("فشل فك تشفير الملف. تأكد من كلمة المرور.")
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ أثناء فك التشفير: {e}")

    def update_pdf_properties(self, file_path, output_path, properties):
        """تحديث خصائص ملف PDF"""
        try:
            success = self.security_module.update_pdf_metadata(file_path, output_path, properties)
            if success:
                self.message_manager.show_success(f"تم تحديث خصائص الملف بنجاح!\nحُفظ في: {output_path}")
            else:
                self.message_manager.show_error("فشل تحديث خصائص الملف.")
        except Exception as e:
            self.message_manager.show_error(f"حدث خطأ أثناء تحديث الخصائص: {e}")


def show_warning_message(parent, message):
    """عرض رسالة تحذير"""
    return QMessageBox.warning(parent, "تحذير", message, QMessageBox.Yes | QMessageBox.No)


def browse_folder_simple(title="اختر مجلدًا"):
    """
    فتح نافذة اختيار مجلد بسيطة باستخدام QFileDialog

    Args:
        title: عنوان النافذة

    Returns:
        str: مسار المجلد المختار أو None إذا تم الإلغاء
    """
    try:
        from PySide6.QtWidgets import QFileDialog
        from PySide6.QtCore import Qt
        import os

        full_title = f"{APP_NAME} - {title}"
        default_dir = os.path.join(os.path.expanduser("~"), "Documents")

        # إنشاء نافذة حوار اختيار المجلد
        dialog = QFileDialog()
        dialog.setWindowTitle(full_title)
        dialog.setDirectory(default_dir)
        dialog.setFileMode(QFileDialog.Directory)
        dialog.setOption(QFileDialog.ShowDirsOnly, True)

        # جعل النافذة تظهر فوق الكل وتعطل الوصول للنافذة الرئيسية
        dialog.setWindowModality(Qt.ApplicationModal)
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowStaysOnTopHint)

        if dialog.exec_() == QFileDialog.Accepted:
            return dialog.selectedFiles()[0] if dialog.selectedFiles() else None
        return None

    except Exception:
        # في حالة فشل QFileDialog، إرجاع None
        return None
